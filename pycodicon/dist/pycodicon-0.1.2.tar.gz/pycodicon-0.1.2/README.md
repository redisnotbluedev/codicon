# pycodicon

A Python package with tools for sacrificing to the Gods of the Codicon.